using System;
using UnityEngine;
using vgame;

namespace _Game.Scripts.Editor.BalanceTool
{
    [Serializable]
    public class BalanceData : BaseData
    {
        public string monsterId;
        public AssetReferenceDetail prefabMonster;
        public Sprite spriteUI;
        public MonsterType monsterType;
        public Rarity rarity;
        public AttackPriority attackPriority;
    }
}