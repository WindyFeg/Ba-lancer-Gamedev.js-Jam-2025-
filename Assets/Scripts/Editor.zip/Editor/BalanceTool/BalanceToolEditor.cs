﻿using UnityEditor;
using UnityEngine;

namespace _Game.Scripts.Editor.BalanceTool
{
    [CustomEditor(typeof(BalanceTool))]
    public class BalanceToolEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            if (GUILayout.Button("Open Editor")) BalanceToolEditorWindow.ShowWindow();
        }
    }
}