﻿using UnityEditor;
using UnityEngine;
using vgame;

namespace _Game.Scripts.Editor.BalanceTool
{
    public class BalanceToolEditorWindow : BaseEditorWindow
    {
        protected TabContainer tabContainer;
        protected GameConfig gameConfig;
        public static BalanceToolEditorWindow Ins { get; private set; }

        [MenuItem("VGames/Balance Tool Editor &z", false, 1)]
        

        public static void ShowWindow()
        {
            Ins = (BalanceToolEditorWindow)GetWindow(typeof(BalanceToolEditorWindow), false, "Balance Tool");
            // Set default size
            Ins.minSize = new Vector2(800, 600);
            Ins.maxSize = new Vector2(1920, 1080); // optional
            Ins.autoRepaintOnSceneChange = true;
        }

        protected override void OnDraw()
        {
            _OnDraw();
        }

        protected override Object GetTarget() => GameConfig.Ins;

        protected override void OnEnable()
        {
            base.OnEnable();
            Ins = this;
            gameConfig = GameConfig.Ins;
            tabContainer = new TabContainer();
            _Init();
            
            // Load monster data when the tool opens
            var loadedMonsters_0 = MyLineUpTab.LoadTempMonster("temp_monster_0");
            var loadedMonsters_1 = MyLineUpTab.LoadTempMonster("temp_monster_1");
            if (loadedMonsters_0 != null && loadedMonsters_1 != null)
            {
                MyLineUpTab.LoadPlayerMonster(loadedMonsters_0, loadedMonsters_1);
                MyLineUpTab.SetUpMonsterList();
                Debug.Log($"Loaded {loadedMonsters_0.Length} + {loadedMonsters_1.Length} temp monsters on open.");
            }
        }

        private void _Init()
        {
            // create view here
            tabContainer.AddTab("My lineup", new MyLineUpTab());
            tabContainer.AddTab("Note", new BalanceToolNoteTab());
        }

        private void _OnDraw()
        {
            tabContainer.DoDraw();

            // customize draw here
        }
    }
    
}