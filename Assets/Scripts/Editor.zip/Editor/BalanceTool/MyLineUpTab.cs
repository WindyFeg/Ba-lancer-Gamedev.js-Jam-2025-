#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using game_service;
using UnityEditor;
using UnityEngine;
using vgame;

namespace _Game.Scripts.Editor.BalanceTool
{
    [Serializable]
    public class PlayerMonsterArrayWrapper
    {
        public PlayerMonsterWrapper[] monsters;
    }

    [Serializable]
    public class PlayerMonsterWrapper
    {
        public string _id;
        public string playerId;
        public string monsterId;
        public bool inLineup;
        public int position;
        public int level;
        public int star;
        public int baseAtk;
        public int baseDef;
        public int baseHp;
        public int curAtk;
        public int curDef;
        public int baseSpeed;
        public int curHp;
        public int skillTurn;
        public string skillDescription;
    }

    public class MyLineUpTab : TabContent
    {
        private readonly TableDrawer<BalanceData> _myLineupTable;
        private static PlayerMonster[] _lstPlayerMonster;
        private PlayerMonster[] _lstPlayerMonsterById = new PlayerMonster[5];

        private static PlayerMonster[] _lstPlayerMonster0;
        private static PlayerMonster[] _monsterInSlot0 = new PlayerMonster[9];
        private bool[] _buttonClickedStates0 = new bool[9];

        private static PlayerMonster[] _lstPlayerMonster1;
        private static PlayerMonster[] _monsterInSlot1 = new PlayerMonster[9];
        private bool[] _buttonClickedStates1 = new bool[9];

        private PlayerMonster _selectedPlayerMonster;
        private static List<MonsterConfig> _allMonsters;
        private static string[] _monsterNames;

        private Texture2D[]
            _buttonImages = new Texture2D[9]; // Assign images to this in OnEnable or wherever you load your textures

        private int _currentLevel;
        private int _currentStar;
        private static int _selectedMonsterIndex = -1;
        private int _selectedMonsterByIdIndex = -1;
        private int _selectedSlotIndex = -1;
        private bool _isTestDatabase;
        private bool _isPlayer0;

        private const string PlayerId0 = "0000000000";
        private const string PlayerId1 = "1111111111";
        private readonly string[] positionNames = { "Front", "Middle", "Back" };
        private readonly Color[] positionColors = { Color.grey, Color.grey, Color.grey };

        public MyLineUpTab()
        {
            _myLineupTable = new TableDrawer<BalanceData>();
            _myLineupTable.AddCol("Icon UI", 50, e =>
            {
                e.spriteUI = Draw.Sprite(e.spriteUI, true, 50, 50);
                Draw.Space(10);
            });
        }

        public static void LoadPlayerMonster(PlayerMonster[] playerMonsters0, PlayerMonster[] playerMonsters1)
        {
            _lstPlayerMonster0 = playerMonsters0;
            _lstPlayerMonster1 = playerMonsters1;
        }


        #region Button Behaviour

        //      __________       .__                .__                     
        //      \______   \ ____ |  |__ _____ ___  _|__| ____  __ _________ 
        //      |    |  _// __ \|  |  \\__  \\  \/ /  |/  _ \|  |  \_  __ \
        //      |    |   \  ___/|   Y  \/ __ \\   /|  (  <_> )  |  /|  | \/
        //      |______  /\___  >___|  (____  /\_/ |__|\____/|____/ |__|   
        //      \/     \/     \/     \/                             
        private void OnSlotSelected(bool isPlayer0, int slotIndex)
        {
            OnTogglePlayerIdChanged(isPlayer0);
            _selectedSlotIndex = slotIndex;
            var monsterInSlot = isPlayer0 ? _monsterInSlot0 : _monsterInSlot1;
            // Show monster info inside the selected slot
            if (monsterInSlot[slotIndex] != null)
            {
                Debug.Log(
                    $"Slot {slotIndex}: {monsterInSlot[slotIndex].monsterId} | Lv.{monsterInSlot[slotIndex].level} | Star.{monsterInSlot[slotIndex].star}");
                // Show monster info
                _selectedMonsterIndex = _allMonsters.FindIndex(m => m.monsterId == monsterInSlot[slotIndex].monsterId);
                _lstPlayerMonster ??= _isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;

                var count = 0;
                foreach (var monster in _lstPlayerMonster)
                {
                    if (monster.monsterId == monsterInSlot[slotIndex].monsterId)
                    {
                        if (monster._id == monsterInSlot[slotIndex]._id)
                        {
                            _selectedMonsterByIdIndex = count;
                            break;
                        }

                        count++;
                    }
                }
            }
            else
            {
                _selectedMonsterIndex = -1;
                _selectedMonsterByIdIndex = -1;
                Debug.Log("No monster in this slot: " + slotIndex);
            }
        }

        private void OnToggleTestDatabaseChanged(bool isEnabled)
        {
            Debug.Log("Toggle changed! Now Database is: " + (isEnabled ? "test" : "live"));
            _isTestDatabase = GameService.ChangeDatabase();
        }

        private void OnTogglePlayerIdChanged(bool isPlayer0)
        {
            if (_isPlayer0 == isPlayer0) return;
            Debug.Log("Toggle changed! List monsters: " + (isPlayer0 ? "Player 0" : "Player 1"));
            _isPlayer0 = isPlayer0;
            _lstPlayerMonster = isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;
        }

        private async void AddMonsterToDatabase(string monsterId)
        {
            var playerId = _isPlayer0 ? PlayerId0 : PlayerId1;
            var createMonster = await GameService.CreateMonsterToDatabase(playerId, monsterId);
            if (createMonster == null)
            {
                Debug.LogError("Add monster to database failed!");
                return;
            }
            
            if (_isPlayer0)
            {
                _lstPlayerMonster0 = await GameService.GetListPlayerMonster(PlayerId0);
                SaveTempMonster(_lstPlayerMonster0, "temp_monster_0");
            }
            else
            {
                _lstPlayerMonster1 = await GameService.GetListPlayerMonster(PlayerId1);
                SaveTempMonster(_lstPlayerMonster1, "temp_monster_1");
            }
            Debug.Log("Add monster to database successfully");

            // TODO Update Monster Info UI
            // There is a bug when you add a monster to the database, the monster info UI is not updated
        }

        private void OnAddMonsterToLineup(string _id)
        {
            // Add monster to lineup
            _lstPlayerMonster ??= _isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;
            var playerMonster = _lstPlayerMonster.Find(m => m._id == _id);
            if (playerMonster != null)
            {
                playerMonster.inLineup = true;
                playerMonster.position = _selectedSlotIndex;

                var monsterInSlot = _isPlayer0 ? _monsterInSlot0 : _monsterInSlot1;
                if (monsterInSlot[_selectedSlotIndex] == null)
                {
                    monsterInSlot[_selectedSlotIndex] = playerMonster;
                    playerMonster.position = _selectedSlotIndex;
                    Debug.Log($"Added monster {_id} to slot {_selectedSlotIndex}");
                }
                else
                {
                    Debug.LogWarning($"Slot {_selectedSlotIndex} is already occupied!");
                    // Remove the monster from the previous slot
                    var previousMonster = monsterInSlot[_selectedSlotIndex];
                    if (previousMonster != null)
                    {
                        previousMonster.inLineup = false;
                        previousMonster.position = null; // Set the position as needed
                    }

                    monsterInSlot[_selectedSlotIndex] = playerMonster;
                    playerMonster.position = _selectedSlotIndex;
                    Debug.Log($"Replaced monster in slot {_selectedSlotIndex} with {_id}");
                }
            }

            SaveTempMonster(_lstPlayerMonster, _isPlayer0 ? "temp_monster_0" : "temp_monster_1");
            // UpdateLineUp(_isPlayer0);
        }

        private void OnRemoveMonsterFromLineup(string _id)
        {
            // Remove monster from lineup
            _lstPlayerMonster ??= _isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;
            var monsterInSlot = _isPlayer0 ? _monsterInSlot0 : _monsterInSlot1;
            var playerMonster = _lstPlayerMonster.Find(m => m._id == _id);
            if (playerMonster != null)
            {
                // Update Data
                var slotIndex = playerMonster.position;
                if (slotIndex != null)
                    monsterInSlot[(int)slotIndex] = null;

                playerMonster.inLineup = false;
                playerMonster.position = null; // Set the position as needed
            }

            SaveTempMonster(_lstPlayerMonster, _isPlayer0 ? "temp_monster_0" : "temp_monster_1");
            // UpdateLineUp(_isPlayer0);
        }

        #endregion

        public static void SetUpMonsterList()
        {
            _allMonsters = GameConfig.Ins.monsters;

            if (_selectedMonsterIndex >= _allMonsters.Count)
                _selectedMonsterIndex = 0;

            _monsterNames = new string[_allMonsters.Count];
            for (int i = 0; i < _allMonsters.Count; i++)
            {
                if (_allMonsters[i].spriteUI == null) continue;
                _monsterNames[i] = $"{_allMonsters[i].name} - {_allMonsters[i].monsterType} - {_allMonsters[i].rarity}";
            }

            SetMonsterToLineUp();
        }

        public async void GetPlayerMonsters()
        {
            if (!GameService.GetIsTestDatabase())
            {
                Debug.LogWarning("Change database to test first !!!");
                return;
            }
            try
            {
                _lstPlayerMonster0 = await GameService.GetListPlayerMonster(PlayerId0);
                _lstPlayerMonster1 = await GameService.GetListPlayerMonster(PlayerId1);
                Debug.Log("Get player monsters successfully: " + _lstPlayerMonster0.Length + " " + _lstPlayerMonster1);
                SetMonsterToLineUp();
                SaveTempMonster(_lstPlayerMonster0, "temp_monster_0");
                SaveTempMonster(_lstPlayerMonster1, "temp_monster_1");
            }
            catch (Exception e)
            {
                Debug.LogError("Error getting player monsters: " + e.Message);
            }
        }

        public static void SetMonsterToLineUp()
        {
            foreach (var playerMonster in _lstPlayerMonster0)
            {
                if (playerMonster.inLineup && playerMonster.position != null)
                {
                    _monsterInSlot0[(int)playerMonster.position] = playerMonster;
                }
            }

            foreach (var playerMonster in _lstPlayerMonster1)
            {
                if (playerMonster.inLineup && playerMonster.position != null)
                {
                    _monsterInSlot1[(int)playerMonster.position] = playerMonster;
                }
            }

            Debug.Log("Set monster to lineup successfully");
        }

        private async void UpdateLevelStarUp(PlayerMonster playerMonster)
        {
            try
            {
                var updateMonster =
                    await GameService.UpdateLevelStarUpCheat(playerMonster._id, playerMonster.level,
                        playerMonster.star);
                // Update the local monster data
                foreach (var monster in _lstPlayerMonster0)
                {
                    if (playerMonster._id == monster._id)
                    {
                        playerMonster._id = updateMonster._id;
                        playerMonster.level = updateMonster.level;
                        playerMonster.star = updateMonster.star;
                        playerMonster.curAtk = updateMonster.curAtk;
                        playerMonster.curDef = updateMonster.curDef;
                        playerMonster.curHp = updateMonster.curHp;
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError(
                    $"Error updating monster {playerMonster._id} Lv.{playerMonster.level} Star.{playerMonster.star}: {e.Message}");
            }
        }

        private LineUpPlayerMonster[] ConvertToLineUpPlayerMonster(PlayerMonster[] lstPlayerMonster)
        {
            var monsterInSlot = _isPlayer0 ? _monsterInSlot0 : _monsterInSlot1;
            var monsterCount = 0;
            foreach (var playerMonster in monsterInSlot)
            {
                if (playerMonster != null)
                {
                    monsterCount++;
                }
            }

            Debug.LogWarning($"> Player {(_isPlayer0 ? "0" : "1")} has {monsterCount} monsters in lineup");
            var res = new LineUpPlayerMonster[monsterCount];
            var index = 0;
            foreach (var playerMonster in lstPlayerMonster)
            {
                if (playerMonster.inLineup && playerMonster.position != null)
                {
                    res[index] = new LineUpPlayerMonster
                    {
                        _id = playerMonster._id,
                        playerId = playerMonster.playerId,
                        monsterId = playerMonster.monsterId,
                        inLineup = playerMonster.inLineup,
                        position = playerMonster.position
                    };
                    index++;
                }
            }

            return res;
        }

        private async void UpdateLineUp(bool isPlayer0)
        {
            var lstPlayerMonster = isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;
            var playerId = isPlayer0 ? PlayerId0 : PlayerId1;
            var lineUpPlayerMonster = ConvertToLineUpPlayerMonster(lstPlayerMonster);
            var res = await GameService.PostListPlayerMonster(playerId, lineUpPlayerMonster);
            await GameService.GetListPlayerMonster(playerId);
            SetUpMonsterList();
            if (res == null)
            {
                Debug.LogError("Update Lineup failed!");
            }
            else
            {
                Debug.Log("Update Lineup successfully!");
            }
        }

        private string CalculateMonsterStats(int type, float baseValue, int level, int star)
        {
            // type: attack = 0, defend = 1, hp = 2
            var upgradeConfig = new float[] { 0.1f, 0.1f, 0.05f };

            var res = Mathf.Floor(baseValue * ((level - 1) * upgradeConfig[type] + 1) * Mathf.Pow(1.1f, (star - 1)) +
                                  0.0001f);
            return res.ToString();
        }

        public override void DoDraw()
        {
            #region Top panel

            // Change database
            var prevValue = _isTestDatabase;
            _isTestDatabase = EditorGUILayout.Toggle("Test database", _isTestDatabase);
            if (_isTestDatabase != prevValue)
            {
                OnToggleTestDatabaseChanged(_isTestDatabase);
            }

            // Reload monster data when test database is changed
            if (Draw.FitButton("Reload data", Color.cyan, 35))
            {
                Debug.Log("Reload data...");
                GetPlayerMonsters();
                SetUpMonsterList();
            }

            #endregion

            #region Line-up panel

            Draw.BeginHorizontal();


            Draw.BeginVertical(GUILayout.Width(250));
            Draw.SpaceAndLabelBoldBox("Opponent LineUp", Color.red);

            Draw.BeginHorizontal();
            if (Draw.FitButton("Update", Color.green, 35))
            {
                UpdateLineUp(false);
            }

            // Draw.Space(20);
            //
            // if (Draw.FitButton("Save JSON", Color.yellow, 35))
            // {
            //     SaveTempMonster(_lstPlayerMonster1, "temp_monster_1");
            // }
            //
            // if (Draw.FitButton("Load JSON", Color.grey, 35))
            // {
            //     _lstPlayerMonster1 = LoadTempMonster("temp_monster_1");
            //     SetMonsterToLineUp();
            // }
            
            Draw.EndHorizontal();

            for (var i = 2; i >= 0; i--)
            {
                Draw.BeginHorizontal();
                for (int j = 0; j < 3; j++)
                {
                    int index = i * 3 + j;

                    // Set the button's background color based on whether it's clicked
                    GUI.backgroundColor = _buttonClickedStates1[index] ? Color.green : positionColors[index / 3];
                    if (GUILayout.Button("", GUILayout.Width(75), GUILayout.Height(75)))
                    {
                        // Reset the clicked states of all buttons
                        for (int k = 0; k < _buttonClickedStates1.Length; k++)
                        {
                            _buttonClickedStates0[k] = false;
                            _buttonClickedStates1[k] = false;
                        }

                        _buttonClickedStates1[index] = true;
                        OnSlotSelected(false, index);
                    }

                    // Get the rect for the last drawn button
                    Rect lastRect = GUILayoutUtility.GetLastRect();

                    // Draw sprite (if available)
                    if (_monsterInSlot1[index] != null)
                    {
                        var monsterSprite = GameConfig.Ins.FindMonster(_monsterInSlot1[index].monsterId).spriteUI;
                        Rect uv = GetSpriteUV(monsterSprite);  // Get sprite UV coordinates
                        float padding = 10f;
                        Rect spriteRect = new Rect(
                            lastRect.x + padding,
                            lastRect.y + padding,
                            lastRect.width - 2 * padding,
                            lastRect.height - 2 * padding
                        );
                        GUI.DrawTextureWithTexCoords(spriteRect, monsterSprite.texture, uv);  // Draw the sprite
                    }
                    
                    // Draw the label (text) on top of the button, centered
                    var label = $"{positionNames[index / 3]}\n{index}";
                    if (_monsterInSlot1[index] != null)
                    {
                        label = $"Lv.{_monsterInSlot1[index].level} - {_monsterInSlot1[index].star}☆";
                    }
                    GUI.Label(lastRect, label, new GUIStyle(GUI.skin.label)
                    {
                        alignment = TextAnchor.UpperCenter,
                        fontSize = 14,
                        fontStyle = FontStyle.Bold,
                        normal = { textColor = Color.white }
                    });

                    // Reset background color after drawing the button
                    GUI.backgroundColor = Color.white;
                }

                Draw.EndHorizontal();
            }

            Draw.SpaceAndLabelBoldBox("My LineUp", Color.green);
            for (var i = 0; i < 3; i++)
            {
                Draw.BeginHorizontal();
                for (int j = 0; j < 3; j++)
                {
                    int index = i * 3 + j;

                    // Set the button's background color based on whether it's clicked
                    GUI.backgroundColor = _buttonClickedStates0[index] ? Color.green : positionColors[index / 3];
                    if (GUILayout.Button("", GUILayout.Width(75), GUILayout.Height(75)))
                    {
                        // Reset the clicked states of all buttons
                        for (int k = 0; k < _buttonClickedStates0.Length; k++)
                        {
                            _buttonClickedStates0[k] = false;
                            _buttonClickedStates1[k] = false;
                        }

                        _buttonClickedStates0[index] = true;
                        OnSlotSelected(true, index);
                    }

                    // Get the rect for the last drawn button
                    Rect lastRect = GUILayoutUtility.GetLastRect();

                    // Draw sprite (if available)
                    if (_monsterInSlot0[index] != null)
                    {
                        var monsterSprite = GameConfig.Ins.FindMonster(_monsterInSlot0[index].monsterId).spriteUI;
                        Rect uv = GetSpriteUV(monsterSprite);  // Get sprite UV coordinates
                        float padding = 10f;
                        Rect spriteRect = new Rect(
                            lastRect.x + padding,
                            lastRect.y + padding,
                            lastRect.width - 2 * padding,
                            lastRect.height - 2 * padding
                        );
                        GUI.DrawTextureWithTexCoords(spriteRect, monsterSprite.texture, uv);  // Draw the sprite
                    }

                    // Draw the label (text) on top of the button, centered
                    var label = $"{positionNames[index / 3]}\n{index}";
                    if (_monsterInSlot0[index] != null)
                    {
                        label = $"Lv.{_monsterInSlot0[index].level} - {_monsterInSlot0[index].star}☆";
                    }
                    GUI.Label(lastRect, label, new GUIStyle(GUI.skin.label)
                    {
                        alignment = TextAnchor.UpperCenter,
                        fontSize = 14,
                        fontStyle = FontStyle.Bold,
                        normal = { textColor = Color.white }
                    });

                    // Reset background color after drawing the button
                    GUI.backgroundColor = Color.white;
                }

                Draw.EndHorizontal();
            }
            
            Draw.BeginHorizontal();
            if (Draw.FitButton("Update", Color.green, 35))
            {
                UpdateLineUp(true);
            }
            
            // Draw.Space(20);
            //
            // if (Draw.FitButton("Save JSON", Color.yellow, 35))
            // {
            //     SaveTempMonster(_lstPlayerMonster1, "temp_monster_1");
            // }
            //
            // if (Draw.FitButton("Load JSON", Color.grey, 35))
            // {
            //     _lstPlayerMonster1 = LoadTempMonster("temp_monster_1");
            //     SetMonsterToLineUp();
            // }
            Draw.EndHorizontal();

            Draw.EndVertical();

            #endregion

            #region Monster Info panel

            // MIDDLE: Monster Info
            if (_lstPlayerMonster0 != null)
            {
                Draw.BeginVertical(GUILayout.Width(250));
                Draw.SpaceAndLabelBoldBox("Monster Info", Color.blue);
                bool prevPlayer = _isPlayer0;
                _isPlayer0 = EditorGUILayout.Toggle("Is Player 0", _isPlayer0);
                if (_isPlayer0 != prevPlayer)
                {
                    OnTogglePlayerIdChanged(_isPlayer0);
                }

                // --- Begin Monster Selector ---
                if (_monsterNames != null && _monsterNames.Length != 0)
                {
                    _selectedMonsterIndex =
                        EditorGUILayout.Popup("Select Monster", _selectedMonsterIndex, _monsterNames);
                }

                // Draw monster info
                if (_selectedMonsterIndex != -1)
                {
                    var selectedMonster = _allMonsters[_selectedMonsterIndex];
                    // Sort _lstMonster by monsterId
                    _lstPlayerMonster ??= _isPlayer0 ? _lstPlayerMonster0 : _lstPlayerMonster1;

                    var count = 0;
                    foreach (var monster in _lstPlayerMonster)
                    {
                        if (monster.monsterId == selectedMonster.monsterId)
                        {
                            _lstPlayerMonsterById[count++] = monster;
                        }
                        // Case count > 5
                        // Expand array
                        if (count >= _lstPlayerMonsterById.Length)
                        {
                            Array.Resize(ref _lstPlayerMonsterById, count + 5);
                        }
                    }

                    var monsterInfos = new string [count];
                    for (int i = 0; i < count; i++)
                    {
                        monsterInfos[i] =
                            $"{_lstPlayerMonsterById[i]._id} - Lv.{_lstPlayerMonsterById[i].level} - Star:{_lstPlayerMonsterById[i].star}";
                    }

                    // _selectedMonsterByIdIndex =
                    // EditorGUILayout.Popup("Select Monster ID", _selectedMonsterByIdIndex, monsterInfos);

                    _selectedMonsterByIdIndex = GUILayout.SelectionGrid(_selectedMonsterByIdIndex, monsterInfos, 1);
                    if (Draw.FitButton("+", Color.green, 25))
                    {
                        AddMonsterToDatabase(selectedMonster.monsterId);
                    }
                    
                    if (_selectedMonsterByIdIndex != -1)
                    {
                        _currentLevel = _lstPlayerMonsterById[_selectedMonsterByIdIndex].level;
                        _currentStar = _lstPlayerMonsterById[_selectedMonsterByIdIndex].star;

                        Draw.Label("Name: " + selectedMonster.name + " Id: " +
                                   _lstPlayerMonsterById[_selectedMonsterByIdIndex]._id);
                        if (_lstPlayerMonsterById[_selectedMonsterByIdIndex].inLineup)
                        {
                            Draw.Label("Lineup: " + _lstPlayerMonsterById[_selectedMonsterByIdIndex].inLineup);
                            Draw.Label("Position: " + _lstPlayerMonsterById[_selectedMonsterByIdIndex].position);
                        }

                        Draw.BeginHorizontal(100);
                        Draw.SpriteThumb(selectedMonster.spriteUI);
                        Draw.SpriteThumb(GameConfig.Ins.FindElement(selectedMonster.monsterType).iconSpriteUI);
                        Draw.SpriteThumb(GameConfig.Ins.FindRarity(selectedMonster.rarity).raritySprite);
                        Draw.EndHorizontal();

                        Draw.BeginHorizontal();
                        Draw.BeginVertical(GUILayout.Width(150));
                        Draw.Label("Level: ");
                        Draw.Label("Star: ");
                        Draw.EndVertical();

                        Draw.BeginVertical();
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].level.ToString());
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].star.ToString());
                        Draw.EndVertical();

                        Draw.BeginVertical();
                        _lstPlayerMonsterById[_selectedMonsterByIdIndex].level =
                            Mathf.Clamp(Draw.Int(_lstPlayerMonsterById[_selectedMonsterByIdIndex].level, 50f), 1, 50);
                        _lstPlayerMonsterById[_selectedMonsterByIdIndex].star =
                            Mathf.Clamp(Draw.Int(_lstPlayerMonsterById[_selectedMonsterByIdIndex].star, 50f), 1, 15);
                        Draw.EndVertical();
                        Draw.EndHorizontal();

                        Draw.SpaceAndLabelBoldBox("Monster Stats | Base - Current - Upgrade", Color.blue);
                        // Stats
                        Draw.BeginHorizontal();
                        Draw.BeginVertical(GUILayout.Width(10));
                        Draw.Label("Attack: ");
                        Draw.Label("Defend: ");
                        Draw.Label("HP: ");
                        Draw.Label("Speed: ");
                        Draw.EndVertical();
                        // // Base stats value
                        // Draw.BeginVertical(GUILayout.Width(10));
                        // Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].baseAtk.ToString());
                        // Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].baseDef.ToString());
                        // Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].baseHp.ToString());
                        // Draw.EndVertical();
                        // Stats value
                        Draw.BeginVertical(GUILayout.Width(10));
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].curAtk.ToString());
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].curDef.ToString());
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].curHp.ToString());
                        Draw.Label(_lstPlayerMonsterById[_selectedMonsterByIdIndex].baseSpeed.ToString());
                        Draw.EndVertical();
                        // Upgrade stats
                        Draw.BeginVertical(GUILayout.Width(10));
                        Draw.Label(CalculateMonsterStats(0, _lstPlayerMonsterById[_selectedMonsterByIdIndex].baseAtk,
                            _currentLevel, _currentStar));
                        Draw.Label(CalculateMonsterStats(1, _lstPlayerMonsterById[_selectedMonsterByIdIndex].baseDef,
                            _currentLevel, _currentStar));
                        Draw.Label(CalculateMonsterStats(2, _lstPlayerMonsterById[_selectedMonsterByIdIndex].baseHp,
                            _currentLevel, _currentStar));
                        Draw.EndVertical();

                        Draw.EndHorizontal();

                        Draw.Label("Priority: " + selectedMonster.attackPriority);
                        Draw.Label("Skill: " + _lstPlayerMonsterById[_selectedMonsterByIdIndex].skillDescription);

                        Draw.BeginHorizontal(); // Action Buttons
                        if (_selectedMonsterByIdIndex != -1)
                        {
                            if (Draw.FitButton("Upgrade", Color.green, 35))
                            {
                                UpdateLevelStarUp(_lstPlayerMonsterById[_selectedMonsterByIdIndex]);
                            }
                        }

                        if (_lstPlayerMonsterById[_selectedMonsterByIdIndex].inLineup)
                        {
                            if (Draw.FitButton("Remove", Color.red, 35))
                            {
                                OnRemoveMonsterFromLineup(_lstPlayerMonsterById[_selectedMonsterByIdIndex]._id);
                            }
                        }
                        else
                        {
                            if (Draw.FitButton("Add to Line up", Color.blue, 35))
                            {
                                OnAddMonsterToLineup(_lstPlayerMonsterById[_selectedMonsterByIdIndex]._id);
                            }
                        }

                        Draw.EndHorizontal();
                    }
                }

                Draw.EndVertical();
            }

            Draw.EndHorizontal();
            if (GUI.changed) Draw.SetDirty(GameConfig.Ins);

            #endregion
        }

        // Method to get the sprite's UV coordinates for drawing the sprite correctly
        private Rect GetSpriteUV(Sprite sprite)
        {
            Rect texRect = sprite.textureRect;
            return new Rect(
                texRect.x / sprite.texture.width,
                texRect.y / sprite.texture.height,
                texRect.width / sprite.texture.width,
                texRect.height / sprite.texture.height
            );
        }

        #region Load & Save

        private static PlayerMonsterWrapper[] ConvertToPlayerMonsterWrapper(PlayerMonster[] playerMonsters)
        {
            var playerMonsterWrappers = new PlayerMonsterWrapper[playerMonsters.Length];
            for (int i = 0; i < playerMonsters.Length; i++)
            {
                var monster = playerMonsters[i];
                playerMonsterWrappers[i] = new PlayerMonsterWrapper
                {
                    _id = monster._id,
                    playerId = monster.playerId,
                    monsterId = monster.monsterId,
                    inLineup = monster.inLineup,
                    position = monster.position ?? -1,
                    level = monster.level,
                    star = monster.star,
                    baseAtk = monster.baseAtk,
                    baseDef = monster.baseDef,
                    baseHp = monster.baseHp,
                    curAtk = monster.curAtk,
                    curDef = monster.curDef,
                    baseSpeed = monster.baseSpeed,
                    curHp = monster.curHp,
                    skillTurn = monster.skillTurn,
                    skillDescription = monster.skillDescription
                };
            }

            return playerMonsterWrappers;
        }

        private static PlayerMonster[] ConvertToPlayerMonster(PlayerMonsterWrapper[] playerMonsterWrappers)
        {
            var playerMonsters = new PlayerMonster[playerMonsterWrappers.Length];
            for (int i = 0; i < playerMonsterWrappers.Length; i++)
            {
                var monsterWrapper = playerMonsterWrappers[i];
                playerMonsters[i] = new PlayerMonster
                {
                    _id = monsterWrapper._id,
                    playerId = monsterWrapper.playerId,
                    monsterId = monsterWrapper.monsterId,
                    inLineup = monsterWrapper.inLineup,
                    level = monsterWrapper.level,
                    star = monsterWrapper.star,
                    baseAtk = monsterWrapper.baseAtk,
                    baseDef = monsterWrapper.baseDef,
                    baseHp = monsterWrapper.baseHp,
                    curAtk = monsterWrapper.curAtk,
                    curDef = monsterWrapper.curDef,
                    baseSpeed = monsterWrapper.baseSpeed,
                    curHp = monsterWrapper.curHp,
                    skillTurn = monsterWrapper.skillTurn,
                    skillDescription = monsterWrapper.skillDescription
                };
                if (monsterWrapper.position != -1)
                    playerMonsters[i].position = monsterWrapper.position;
            }

            return playerMonsters;
        }

        public static void SaveTempMonster(PlayerMonster[] data, string fileName)
        {
            var saveDirectory = Path.Combine(Application.dataPath, "SavedData");
            if (!Directory.Exists(saveDirectory))
            {
                Directory.CreateDirectory(saveDirectory);
            }

            var path = Path.Combine(saveDirectory, $"{fileName}.json");

            var dataWrappers = ConvertToPlayerMonsterWrapper(data);

            var wrapper = new PlayerMonsterArrayWrapper { monsters = dataWrappers };

            var json = JsonUtility.ToJson(wrapper, true);
            File.WriteAllText(path, json);

            Debug.Log($"Monster array saved to: {path}");
        }

        public static PlayerMonster[] LoadTempMonster(string fileName)
        {
            var path = Path.Combine(Application.dataPath, "SavedData", $"{fileName}.json");

            if (!File.Exists(path))
            {
                Debug.LogWarning("⚠️ No saved monster file found in Assets/SavedData.");
                return null;
            }

            try
            {
                var json = File.ReadAllText(path);
                var monsters = JsonUtility.FromJson<PlayerMonsterArrayWrapper>(json)?.monsters;

                if (monsters != null)
                {
                    var res = ConvertToPlayerMonster(monsters);
                    Debug.Log($"✅ Loaded {monsters.Length} monsters from Assets/SavedData");
                    return res;
                }
                else
                {
                    Debug.LogWarning("⚠️ Failed to deserialize monster data.");
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"❌ Error loading monsters: {ex.Message}");
                return null;
            }
        }


        #endregion
    }
}
#endif