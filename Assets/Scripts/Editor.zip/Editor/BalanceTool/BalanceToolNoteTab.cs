using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class BalanceToolNoteTab : TabContent
{

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Before Battle", Color.green);
        
        // *Note
        Draw.Label("Make sure ENABLE Test Database - A Toggle button in LineUp Tab");
        Draw.Label("-------------------------------");
        Draw.Label("Make sure GameConfig.isTestGame = true before BATTLE");
        Draw.Label("ALT + V to open GameConfig Tab");
        Draw.Label("You only need to enable it once!");
        Draw.Label("-------------------------------");
        
        Draw.SpaceAndLabelBoldBox("Monster", Color.cyan);
        Draw.Label("Flow Upgrade monster: Select monster -> Change Level & Star -> Upgrade button");
        Draw.Label("You're viewing preview stats. Tap 'Upgrade' to apply changes");
        Draw.Label("Flow Change monster: Select slot -> Select Monster (if needed) -> Apply / Remove");
        
        Draw.SpaceAndLabelBoldBox("Monster Data", Color.yellow);
        Draw.Label("Updated monster data in the TEST database? Reload to preview it in-game!");
        Draw.Label("Click Reload to fetch all monster data from the server and log it as a JSON file in the console.");
        
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}