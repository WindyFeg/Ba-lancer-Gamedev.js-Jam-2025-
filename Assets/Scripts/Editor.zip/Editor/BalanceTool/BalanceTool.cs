﻿#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using vgame;

namespace _Game.Scripts.Editor.BalanceTool
{
    public class BalanceTool : SingletonScriptObject<BalanceTool>
    {
        [MenuItem("VGames/Game Setting &z", false, 1)]
        private static void OnMenuItemClicked()
        {
            
        }
        
        public List<BalanceData> myLineUp = new();
        public List<BalanceData> opponent = new();
        
    }
}
#endif
