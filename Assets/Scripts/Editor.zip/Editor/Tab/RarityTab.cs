﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class RarityTab : TabContent
{
    private readonly TableDrawer<RarityConfig> rarityTable;

    public RarityTab()
    {
        rarityTable = new TableDrawer<RarityConfig>();
        rarityTable.AddCol("type", 100, e =>
        {
            e.type = (Rarity)Draw.Enum(e.type, 80);
            Draw.Space(10);
        });
        rarityTable.AddCol("Sprite", 50, e => { e.raritySprite = Draw.Sprite(e.raritySprite, true, 50, 50); Draw.Space(10); });
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Element", Color.green);
        rarityTable.DoDraw(GameConfig.Ins.rarities);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.rarities.Add(new RarityConfig
            {
                type = Rarity.C,
                raritySprite = null
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}