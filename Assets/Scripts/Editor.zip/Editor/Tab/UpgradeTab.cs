using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class UpgradeTab : TabContent
{
    private readonly TableDrawer<LevelUpConfig> levelUpTable;
    private readonly TableDrawer<MergeConfig> mergeTable;
    private readonly TableDrawer<TapConfig> tapTable;

    public UpgradeTab()
    {
        levelUpTable = new TableDrawer<LevelUpConfig>();
        mergeTable = new TableDrawer<MergeConfig>();
        tapTable = new TableDrawer<TapConfig>();
        
        levelUpTable.AddCol("Level", 50, e => { e.level = Draw.Int(e.level, 40); Draw.Space(10); });   
        levelUpTable.AddCol("Gold", 70, e => { e.gold = Draw.Int(e.gold, 60); Draw.Space(10); });
        levelUpTable.AddCol("Clover", 50, e => { e.clover = Draw.Int(e.clover, 40); Draw.Space(10); });
        
        mergeTable.AddCol("Star Level", 70, e => { e.starLevel = Draw.Int(e.starLevel, 60); Draw.Space(10); });
        mergeTable.AddCol("Monster Required", 110, e => { e.monsterRequired = Draw.Int(e.monsterRequired, 100); Draw.Space(10); });
        mergeTable.AddCol("Gold", 70, e => { e.gold = Draw.Int(e.gold, 60); Draw.Space(10); });
        
        tapTable.AddCol("Rarity", 50, e => { e.rarity = Draw.Enum(e.rarity, 40); Draw.Space(10); });
        tapTable.AddCol("Star Level", 70, e => { e.starLevel = Draw.Int(e.starLevel, 60); Draw.Space(10); });
        tapTable.AddCol("Gold Per Tap", 90, e => { e.goldPerTap = Draw.Int(e.goldPerTap, 80); Draw.Space(10); });
        tapTable.AddCol("Max Gold", 70, e => { e.maxGold = Draw.Int(e.maxGold, 60); Draw.Space(10); });
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Level Up Config", Color.green);
        levelUpTable.DoDraw(GameConfig.Ins.levelUps);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.levelUps.Add(new LevelUpConfig
            {
                level = GameConfig.Ins.levelUps.Count + 1,
                gold = 0,
                clover = 0
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Merge Config", Color.green);
        mergeTable.DoDraw(GameConfig.Ins.merges);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.merges.Add(new MergeConfig
            {
                starLevel = GameConfig.Ins.merges.Count + 1,
                monsterRequired = GameConfig.Ins.merges.Count + 1,
                gold = 0
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Tap Config", Color.green);
        tapTable.DoDraw(GameConfig.Ins.taps);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.taps.Add(new TapConfig
            {
                rarity = Rarity.C,
                starLevel = GameConfig.Ins.taps.Count + 1,
                goldPerTap = GameConfig.Ins.taps.Count + 1,
                maxGold = 0
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}
