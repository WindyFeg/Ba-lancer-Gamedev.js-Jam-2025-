using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class MonstersTab : TabContent
{
    private TabContainer tabContainer;


    public MonstersTab()
    {
        tabContainer = new TabContainer();
        tabContainer.AddTab("Monster", new MonsterTab());
        tabContainer.AddTab("Element", new ElementTab());
        tabContainer.AddTab("Rarity", new RarityTab());
        tabContainer.AddTab("Upgrade", new UpgradeTab());
    }

    public override void DoDraw()
    {
        tabContainer.DoDraw();

    }
}

public class MonsterTab : TabContent
{
    private readonly TableDrawer<MonsterConfig> monsterTable;

    public MonsterTab()
    {
        monsterTable = new TableDrawer<MonsterConfig>();
        monsterTable.AddCol("ID", 50, e => { e.id = Draw.Int(e.id, 30); Draw.Space(20); });
        monsterTable.AddCol("Name", 150, e => { e.name = Draw.Text(e.name, 130); Draw.Space(20); });
        monsterTable.AddCol("MonsterID", 200, e => { e.monsterId = Draw.Text(e.monsterId, 180); Draw.Space(20); });
        monsterTable.AddCol("Monster", 170, e => { e.prefabMonster.Draw(150); Draw.Space(20); });
        monsterTable.AddCol("Type", 90, e => { e.monsterType = Draw.Enum(e.monsterType, 70); Draw.Space(20); });
        monsterTable.AddCol("Rarity", 90, e => { e.rarity = Draw.Enum(e.rarity, 70); Draw.Space(20); });
        monsterTable.AddCol("AttackPriority", 120, e => { e.attackPriority = Draw.Enum(e.attackPriority, 100); Draw.Space(20); });
        monsterTable.AddCol("sprite UI", 70, e => { e.spriteUI = Draw.Sprite(e.spriteUI, true, 50, 50); Draw.Space(20); });
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Monster", Color.green);
        monsterTable.DoDraw(GameConfig.Ins.monsters);
        if (Draw.Button("+", Color.green, Color.white, 150))
        {
            GameConfig.Ins.monsters.Add(new MonsterConfig
            {
                id = GameConfig.Ins.monsters.Count,
                name = "New Monster",
                monsterId = "monster_" + (GameConfig.Ins.monsters.Count + 1),
                prefabMonster = null,
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}
