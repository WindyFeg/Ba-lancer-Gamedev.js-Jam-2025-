﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class BoostTab : TabContent
{
    private readonly TableDrawer<BoostConfig> boostTable;

    public BoostTab()
    {
        boostTable = new TableDrawer<BoostConfig>();
        boostTable.AddCol("multiplier", 100, e =>
        {
            e.multiplier = Draw.Int(e.multiplier, 80);
            Draw.Space(10);
        });
        boostTable.AddCol("Friend", 50, e => { e.friendInvite = Draw.Int(e.friendInvite, 50); Draw.Space(10); });
        boostTable.AddCol("Star", 50, e => { e.starPrice = Draw.Int(e.starPrice, 50); Draw.Space(10); });
        boostTable.AddCol("USD", 50, e => { e.usdPrice = Draw.Int(e.usdPrice, 50); Draw.Space(10); });
        
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Tap Boost", Color.green);
        boostTable.DoDraw(GameConfig.Ins.boosts);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.boosts.Add(new BoostConfig()
            {
                multiplier = GameConfig.Ins.boosts.Count + 1,
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}