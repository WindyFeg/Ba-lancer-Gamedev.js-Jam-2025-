﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class GlobalTab : TabContent
{
    private TabContainer tabContainer;

    public GlobalTab()
    {
        tabContainer = new TabContainer();
        tabContainer.AddTab("Setting", new SettingTab());
    }

    public override void DoDraw()
    {
        tabContainer.DoDraw();
    }
}

public class SettingTab : TabContent
{
    public override void DoDraw()
    {
        Draw.SpaceAndLabelBoldBox("Service URL", Color.green);
        GUILayout.Space(10);

        Draw.BeginHorizontal();

        Draw.BeginVertical();
        GameConfig.Ins.GameServiceURLProduct = Draw.TextField("URL Product", GameConfig.Ins.GameServiceURLProduct, 400);
        GameConfig.Ins.GameServiceURLStaging = Draw.TextField("URL Staging", GameConfig.Ins.GameServiceURLStaging, 400);
        GameConfig.Ins.GameServiceURLDev = Draw.TextField("URL Dev", GameConfig.Ins.GameServiceURLDev, 400);
        Draw.EndVertical();

        GUILayout.Space(20);

        Draw.BeginVertical();
        var newEnvironment = Draw.EnumField("Environment", GameConfig.Ins.environment, 200);
        if (newEnvironment != GameConfig.Ins.environment)
        {
            GameConfig.Ins.environment = newEnvironment;
            switch (GameConfig.Ins.environment)
            {
                case EnvironmentTyle.Production:
                    GameConfig.Ins.GameServiceURL = GameConfig.Ins.GameServiceURLProduct;
                    break;
                case EnvironmentTyle.Staging:
                    GameConfig.Ins.GameServiceURL = GameConfig.Ins.GameServiceURLStaging;
                    break;
                case EnvironmentTyle.Development:
                    GameConfig.Ins.GameServiceURL = GameConfig.Ins.GameServiceURLDev;
                    break;
            }
        }
        Draw.Label($"Current URL:                    {GameConfig.Ins.GameServiceURL}", 400);
        GameConfig.Ins.isTestGame = Draw.ToggleField("Test Game: ", GameConfig.Ins.isTestGame, 20);
        Draw.EndVertical();

        GUILayout.Space(20);

        Draw.BeginVertical();
        GameConfig.Ins.platformType = Draw.EnumField("Platform", GameConfig.Ins.platformType, 200);
        GameConfig.Ins.ShopID = Draw.TextField("Shop ID", GameConfig.Ins.ShopID, 200);

        Draw.EndVertical();

        Draw.FlexibleSpace();
        Draw.EndHorizontal();

        Draw.SpaceAndLabelBoldBox("", Color.green);
    }
}
