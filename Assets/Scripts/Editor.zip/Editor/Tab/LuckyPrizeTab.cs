﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class LuckyPrizeTab : TabContent
{
    private readonly TableDrawer<LuckyPrizeConfig> luckyPrize;

    public LuckyPrizeTab()
    {
        luckyPrize = new TableDrawer<LuckyPrizeConfig>();
        luckyPrize.AddCol("Index", 80, e => { e.index = Draw.Int(e.index, 70); Draw.Space(10); });
        luckyPrize.AddCol("type", 130, e =>
        {
            e.type = (LuckyPrizeType)Draw.Enum(e.type, 120);
            Draw.Space(10);
        });
        luckyPrize.AddCol("Sprite", 50, e => { e.sprite = Draw.Sprite(e.sprite, true, 50, 50); Draw.Space(10); });
        luckyPrize.AddCol("Quantity", 80, e => { e.quantity = Draw.Int(e.quantity, 70); Draw.Space(10); });
        luckyPrize.AddCol("Rate", 70, e => { e.rate = Draw.Float(e.rate, 60); Draw.Space(10); });
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Element", Color.green);
        luckyPrize.DoDraw(GameConfig.Ins.luckyPrizes);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.luckyPrizes.Add(new LuckyPrizeConfig
            {
                index = GameConfig.Ins.luckyPrizes.Count + 1,
                type = LuckyPrizeType.Egg,
                quantity = 1,
                rate = 0.1f
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}