using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vgame;

public class ElementTab : TabContent
{
    private readonly TableDrawer<ElementConfig> elementTable;

    public ElementTab()
    {
        elementTable = new TableDrawer<ElementConfig>();
        elementTable.AddCol("type", 100, e =>
        {
            e.type = (MonsterType)Draw.Enum(e.type, 80);
            Draw.Space(10);
        });
        elementTable.AddCol("Icon Gameplay", 50, e => { e.iconSpriteGamePlay = Draw.Sprite(e.iconSpriteGamePlay, true, 50, 50); Draw.Space(10); });
        elementTable.AddCol("Icon UI", 50, e => { e.iconSpriteUI = Draw.Sprite(e.iconSpriteUI, true, 50, 50); Draw.Space(10); });
        elementTable.AddCol("Egg Sprite", 50, e => { e.eggSprite = Draw.Sprite(e.eggSprite, true, 50, 80); Draw.Space(10); });
        elementTable.AddCol("Egg Card", 50, e => { e.eggCard = Draw.Sprite(e.eggCard, true, 50, 80); Draw.Space(10); });
        elementTable.AddCol("Egg Name", 150, e => { e.eggName = Draw.Text(e.eggName, 130); Draw.Space(20); });
        elementTable.AddCol("Monster Card", 50, e => { e.monsterCard = Draw.Sprite(e.monsterCard, true, 50, 80); Draw.Space(10); });
    }

    public override void DoDraw()
    {
        Draw.BeginHorizontal();
        Draw.BeginVertical(Draw.SubContentStyle);
        Draw.SpaceAndLabelBoldBox("Element", Color.green);
        elementTable.DoDraw(GameConfig.Ins.elements);
        if (Draw.Button("+", Color.blue, Color.white, 150))
        {
            GameConfig.Ins.elements.Add(new ElementConfig
            {
                type = MonsterType.FIRE,
                iconSpriteUI = null
            });
            Draw.SetDirty(GameConfig.Ins);
        }
        Draw.EndVertical();
        Draw.EndHorizontal();
        if (GUI.changed) Draw.SetDirty(GameConfig.Ins);
    }
}
